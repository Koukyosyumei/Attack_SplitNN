from .mia.splitmia import SplitMIA
from .model_inversion import fsha, fshamnist
