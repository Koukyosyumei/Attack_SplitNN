from .model import Client, Server, SplitNN
