from .mia.splitmia import SplitMIA
from .modelinversion import fsha, fshamnist
