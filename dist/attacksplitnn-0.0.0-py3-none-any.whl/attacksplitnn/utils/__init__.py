from .functions import DataSet
from .torchmodule import Conv2d, ConvTranspose2d
